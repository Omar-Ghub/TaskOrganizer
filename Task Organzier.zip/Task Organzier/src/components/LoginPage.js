import React, { useState } from "react";
import logo from "./assets/logo.png";

export default function LoginPage({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
    if (username === "Admin" && password === "Password") {
      setError("");
      onLogin();
    } else {
      setError("**Incorrect Password or Username**");
    }
  };

  return React.createElement(
    "div",
    { style: { display: "flex", flexDirection: "column", alignItems: "center", marginTop: "100px" } },

    React.createElement("img", { 
      src: logo, 
      alt: "Logo", 
      style: { width: "30%",height: "20%", marginBottom: "20px" } 
    }),

    React.createElement("input", {
      type: "text",
      placeholder: "Username",
      value: username,
      onChange: e => setUsername(e.target.value),
      style: { padding: "8px", margin: "6px 0", borderRadius: "4px", border: "1px solid #ccc" }
    }),

    React.createElement("input", {
      type: "password",
      placeholder: "Password",
      value: password,
      onChange: e => setPassword(e.target.value),
      style: { padding: "8px", margin: "6px 0", borderRadius: "4px", border: "1px solid #ccc" }
    }),

    React.createElement("button", {
      onClick: handleLogin,
      style: { padding: "8px 12px", marginTop: "10px", borderRadius: "4px", cursor: "pointer" }
    }, "Login"),

    error && React.createElement("div", { style: { color: "red", marginTop: "10px" } }, error)
  );
}
