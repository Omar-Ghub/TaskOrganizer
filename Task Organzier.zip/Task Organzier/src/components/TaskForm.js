import React, { useState, useEffect } from "react";

export default function TaskForm({ task, onSave, onCancel }) {
  const [title, setTitle] = useState(task ? task.title : "");
  const [description, setDescription] = useState(task ? task.description : "");
  const [category, setCategory] = useState(task ? task.category : "");
  const [status, setStatus] = useState(task ? task.status : "Incomplete");
  const [deadline, setDeadline] = useState(task ? task.deadline : "");

  const isFormValid = title && description && category && status && deadline;

  const handleSave = () => {
    if (!isFormValid) return;
    const newTask = {
      ...task,
      title,
      description,
      category,
      status,
      deadline
    };
    onSave(newTask);
  };

  return React.createElement(
    "div",
    { style: { padding: "20px", maxWidth: "500px", margin: "40px auto", border: "1px solid #ccc", borderRadius: "8px", background: "#fff" } },
    React.createElement("h2", null, task ? "Edit Task" : "Create Task"),
    
    // Title
    React.createElement("input", {
      type: "text",
      placeholder: "Title",
      value: title,
      onChange: e => setTitle(e.target.value),
      style: { display: "block", width: "100%", padding: "8px", margin: "10px 0", borderRadius: "4px", border: "1px solid #ccc" }
    }),

    // Description
    React.createElement("textarea", {
      placeholder: "Description",
      value: description,
      onChange: e => setDescription(e.target.value),
      style: { display: "block", width: "100%", padding: "8px", margin: "10px 0", borderRadius: "4px", border: "1px solid #ccc", minHeight: "80px" }
    }),

    // Category
    React.createElement("input", {
      type: "text",
      placeholder: "Category",
      value: category,
      onChange: e => setCategory(e.target.value),
      style: { display: "block", width: "100%", padding: "8px", margin: "10px 0", borderRadius: "4px", border: "1px solid #ccc" }
    }),

    // Status
    React.createElement("select", {
      value: status,
      onChange: e => setStatus(e.target.value),
      style: { display: "block", width: "100%", padding: "8px", margin: "10px 0", borderRadius: "4px", border: "1px solid #ccc" }
    },
      React.createElement("option", { value: "Incomplete" }, "Incomplete"),
      React.createElement("option", { value: "Complete" }, "Complete"),
      React.createElement("option", { value: "Postponed" }, "Postponed")
    ),

    // Deadline
    React.createElement("input", {
      type: "date",
      value: deadline,
      onChange: e => setDeadline(e.target.value),
      style: { display: "block", width: "100%", padding: "8px", margin: "10px 0", borderRadius: "4px", border: "1px solid #ccc" }
    }),

    // Buttons
    React.createElement("div", { style: { marginTop: "20px", display: "flex", justifyContent: "space-between" } },
      React.createElement("button", {
        onClick: handleSave,
        disabled: !isFormValid,
        style: { padding: "8px 12px", borderRadius: "4px", cursor: isFormValid ? "pointer" : "not-allowed" }
      }, "Save Task"),
      React.createElement("button", {
        onClick: onCancel,
        style: { padding: "8px 12px", borderRadius: "4px", cursor: "pointer" }
      }, "Cancel")
    )
  );
}
