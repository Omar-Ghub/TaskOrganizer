import React, { useState } from "react";
import TaskForm from "./TaskForm";
import logo from "./assets/logo.png";

//hardcoded demo tasks
const initialTasks = [
  { id: 1, title: "Finish Report", description: "Complete annual report", category: "Work", status: "Incomplete", deadline: "2025-12-10" },
  { id: 2, title: "Workout", description: "Go to the gym", category: "Exercise", status: "Incomplete", deadline: "2025-12-06" },
  { id: 3, title: "Clean Room", description: "Organize and clean room", category: "Cleaning", status: "Complete", deadline: "2025-12-05" }
];

export default function Homepage({ onSignOut }) {
  const [tasks, setTasks] = useState(initialTasks);
  const [search, setSearch] = useState("");
  const [sortOption, setSortOption] = useState("alphabeticalAsc");
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  //task filtering and sorting
  const filteredTasks = tasks.filter(task =>
    task.title.toLowerCase().includes(search.toLowerCase()) ||
    task.category.toLowerCase().includes(search.toLowerCase())
  );

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    switch (sortOption) {
      case "alphabeticalAsc": return a.title.localeCompare(b.title);
      case "alphabeticalDesc": return b.title.localeCompare(a.title);
      case "deadlineAsc": return new Date(a.deadline) - new Date(b.deadline);
      case "deadlineDesc": return new Date(b.deadline) - new Date(a.deadline);
      case "status": return a.status.localeCompare(b.status);
      default: return 0;
    }
  });

  const handleDelete = (id) => {
    if (confirm(`Are you sure you want to delete "${tasks.find(t => t.id === id).title}"?`)) {
      setTasks(tasks.filter(t => t.id !== id));
    }
  };

  const renderTasks = sortedTasks.map(task =>
    React.createElement(
      "div",
      { key: task.id, style: { background: "#fff", padding: "12px", marginBottom: "10px", borderRadius: "6px", boxShadow: "0 2px 5px rgba(0,0,0,0.1)" } },
      React.createElement("h3", null, task.title),
      React.createElement("p", null, task.description),
      React.createElement("p", null, `Category: ${task.category} | Status: ${task.status} | Deadline: ${task.deadline}`),
      React.createElement("div", null,
        React.createElement("button", {
          onClick: () => { setEditingTask(task); setShowForm(true); },
          style: { marginRight: "10px" }
        }, "Edit"),
        React.createElement("button", { onClick: () => handleDelete(task.id) }, "Delete")
      )
    )
  );

  return React.createElement(
    "div",
    { style: { padding: "20px", fontFamily: "Arial" } },

    // Header
    React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } },
      React.createElement("img", { src: logo, alt: "Logo", style: { width: "15%", height:"8%" } }),
      React.createElement("button", { onClick: onSignOut, style: { padding: "8px 12px", borderRadius: "4px", cursor: "pointer" } }, "Sign Out")
    ),

    React.createElement("button", {
      onClick: () => { setEditingTask(null); setShowForm(true); },
      style: { margin: "20px 0", padding: "8px 12px", borderRadius: "4px", cursor: "pointer" }
    }, "Create New Task"),

    React.createElement("div", { style: { marginBottom: "20px" } },
      React.createElement("input", {
        type: "text",
        placeholder: "Search tasks...",
        value: search,
        onChange: e => setSearch(e.target.value),
        style: { padding: "8px", marginRight: "10px", borderRadius: "4px", border: "1px solid #ccc" }
      }),
      React.createElement("select", {
        value: sortOption,
        onChange: e => setSortOption(e.target.value),
        style: { padding: "8px", borderRadius: "4px", border: "1px solid #ccc" }
      },
        React.createElement("option", { value: "alphabeticalAsc" }, "Alphabetical ↑"),
        React.createElement("option", { value: "alphabeticalDesc" }, "Alphabetical ↓"),
        React.createElement("option", { value: "deadlineAsc" }, "Deadline ↑"),
        React.createElement("option", { value: "deadlineDesc" }, "Deadline ↓"),
        React.createElement("option", { value: "status" }, "Status")
      )
    ),

    showForm
      ? React.createElement(TaskForm, {
          task: editingTask,
          onSave: (taskData) => {
            if (editingTask) {
              setTasks(tasks.map(t => t.id === taskData.id ? taskData : t));
            } else {
              setTasks([...tasks, { ...taskData, id: Date.now() }]);
            }
            setShowForm(false);
          },
          onCancel: () => setShowForm(false)
        })
      : renderTasks,

    React.createElement("div", { style: { marginTop: "50px", textAlign: "left", color: "#666" } }, "Call Support (not real): 555-123-4567")
  );
}
