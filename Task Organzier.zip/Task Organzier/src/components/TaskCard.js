const React = require("react");
const { useNavigate } = require("react-router-dom");
const DeleteModal = require("./DeleteModal");

function TaskCard({ task }) {
  const navigate = useNavigate();

  return React.createElement(
    "div",
    { className: "task-card" },
    React.createElement("h3", null, task.title),
    React.createElement("p", null, task.description),
    React.createElement("p", null, "Category: " + task.category),
    React.createElement("p", null, "Status: " + task.status),
    React.createElement("p", null, "Deadline: " + task.deadline),
    React.createElement(
      "button",
      { onClick: () => navigate("/edit-task/" + task.id) },
      "Edit Task"
    ),
    React.createElement(DeleteModal, { task })
  );
}

module.exports = TaskCard;
