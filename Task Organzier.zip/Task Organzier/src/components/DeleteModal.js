const React = require("react");
const { useState } = React;

function DeleteModal({ task }) {
  const [show, setShow] = useState(false);

  const handleDelete = () => {
    alert('Task "' + task.title + '" deleted!');
    setShow(false);
  };

  return React.createElement(
    React.Fragment,
    null,
    React.createElement("button", { onClick: () => setShow(true) }, "Delete"),
    show &&
      React.createElement(
        "div",
        { className: "modal" },
        React.createElement("p", null, 'Are you sure you want to delete "' + task.title + '"?'),
        React.createElement("button", { onClick: handleDelete }, "Confirm"),
        React.createElement("button", { onClick: () => setShow(false) }, "Cancel")
      )
  );
}

module.exports = DeleteModal;
