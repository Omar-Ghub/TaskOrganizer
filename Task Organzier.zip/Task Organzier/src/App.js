import React, { useState } from "react";
import LoginPage from "./components/LoginPage";
import Homepage from "./components/Homepage";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  return React.createElement(
    loggedIn ? Homepage : LoginPage,
    { onSignOut: () => setLoggedIn(false), onLogin: () => setLoggedIn(true) }
  );
}

